import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Star, Flame, Heart } from "lucide-react";
import type { WeeklySpecial } from "@shared/schema";

export default function WeeklySpecials() {
  const { data: specials, isLoading } = useQuery<WeeklySpecial[]>({
    queryKey: ["/api/specials"],
  });

  const getIcon = (index: number) => {
    const icons = [Star, Flame, Heart];
    const Icon = icons[index % icons.length];
    return <Icon className="text-secondary text-2xl" />;
  };

  return (
    <section className="py-16 bg-primary text-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h3 className="font-playfair text-3xl font-bold mb-4">Diese Woche Besonders</h3>
          <p className="text-xl text-gray-100">Frische saisonale Spezialitäten - nur für kurze Zeit verfügbar</p>
        </div>

        {isLoading ? (
          <div className="grid md:grid-cols-3 gap-8">
            {[...Array(3)].map((_, i) => (
              <Card key={i} className="bg-white bg-opacity-10 backdrop-blur-lg animate-pulse">
                <CardContent className="p-6">
                  <div className="h-6 bg-white bg-opacity-20 rounded mb-4"></div>
                  <div className="h-4 bg-white bg-opacity-20 rounded mb-2"></div>
                  <div className="h-16 bg-white bg-opacity-20 rounded mb-4"></div>
                  <div className="h-6 bg-white bg-opacity-20 rounded w-24"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="grid md:grid-cols-3 gap-8">
            {specials?.map((special, index) => (
              <Card key={special.id} className="bg-white bg-opacity-10 backdrop-blur-lg">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    {getIcon(index)}
                    <h4 className="font-playfair text-xl font-semibold ml-3">{special.availableDays}</h4>
                  </div>
                  <h5 className="text-lg font-semibold mb-2">{special.name}</h5>
                  <p className="text-gray-100 text-sm mb-4">{special.description}</p>
                  <div className="text-secondary font-bold text-lg">{special.price}</div>
                </CardContent>
              </Card>
            )) || []}
          </div>
        )}
      </div>
    </section>
  );
}
