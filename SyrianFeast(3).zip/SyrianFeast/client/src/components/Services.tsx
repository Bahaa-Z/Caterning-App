import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Building, Heart, Users, Truck, UtensilsCrossed, Coffee, Flower, MapPin, ShoppingBag } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function Services() {
  return (
    <section id="services" className="py-20 bg-beige">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h3 className="font-playfair text-4xl font-bold text-primary mb-4">Unsere Catering-Leistungen</h3>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto">
            Von intimen Familienfeiern bis zu großen Firmenevents – wir bieten maßgeschneiderte 
            kulinarische Lösungen für jeden Anlass.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          <Card className="bg-white hover:shadow-xl transition-shadow">
            <CardHeader>
              <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mb-4">
                <Building className="text-white text-2xl" />
              </div>
              <CardTitle className="font-playfair text-2xl text-primary">Firmencatering</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700 mb-6">
                Beeindrucken Sie Ihre Geschäftspartner mit authentischen syrischen Spezialitäten. 
                Von Business-Lunches bis zu großen Firmenevents.
              </p>
              <div className="space-y-2">
                <div className="flex items-center text-sm text-gray-600">
                  <Badge variant="outline" className="mr-2">✓</Badge>
                  Konferenzverpflegung
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <Badge variant="outline" className="mr-2">✓</Badge>
                  Büro-Mittagessen
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <Badge variant="outline" className="mr-2">✓</Badge>
                  Firmenevents & Feiern
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <Badge variant="outline" className="mr-2">✓</Badge>
                  Produktpräsentationen
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white hover:shadow-xl transition-shadow damascus-card">
            <CardHeader>
              <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center mb-4">
                <Heart className="text-primary text-2xl" />
              </div>
              <CardTitle className="font-playfair text-2xl text-primary">Hochzeitscatering</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700 mb-6">
                Machen Sie Ihren besonderen Tag unvergesslich mit einem Fest der Sinne. 
                Traditionelle syrische Hochzeitsmenüs mit modernem Touch.
              </p>
              <div className="space-y-2">
                <div className="flex items-center text-sm text-gray-600">
                  <Badge variant="outline" className="mr-2">✓</Badge>
                  Mehrgängige Festmenüs
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <Badge variant="outline" className="mr-2">✓</Badge>
                  Orientalische Süßspeisen
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <Badge variant="outline" className="mr-2">✓</Badge>
                  Buffet & À-la-carte
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <Badge variant="outline" className="mr-2">✓</Badge>
                  Komplette Eventplanung
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white hover:shadow-xl transition-shadow">
            <CardHeader>
              <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center mb-4">
                <Users className="text-white text-2xl" />
              </div>
              <CardTitle className="font-playfair text-2xl text-primary">Private Events</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700 mb-6">
                Geburtstage, Familienfeier oder besondere Anlässe – wir bringen die Wärme 
                der syrischen Gastfreundschaft zu Ihnen nach Hause.
              </p>
              <div className="space-y-2">
                <div className="flex items-center text-sm text-gray-600">
                  <Badge variant="outline" className="mr-2">✓</Badge>
                  Geburtstagsfeier
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <Badge variant="outline" className="mr-2">✓</Badge>
                  Familienfeste
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <Badge variant="outline" className="mr-2">✓</Badge>
                  Dinner-Partys
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <Badge variant="outline" className="mr-2">✓</Badge>
                  Religiöse Feiern
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white hover:shadow-xl transition-shadow">
            <CardHeader>
              <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mb-4">
                <Truck className="text-white text-2xl" />
              </div>
              <CardTitle className="font-playfair text-2xl text-primary">Lieferung & Takeaway</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700 mb-6">
                Genießen Sie unsere authentischen syrischen Spezialitäten bequem zu Hause 
                oder holen Sie Ihr Lieblingsgericht direkt bei uns ab.
              </p>
              <div className="space-y-2">
                <div className="flex items-center text-sm text-gray-600">
                  <Badge variant="outline" className="mr-2">✓</Badge>
                  Kostenlose Lieferung ab 40€
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <Badge variant="outline" className="mr-2">✓</Badge>
                  Takeaway-Service
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <Badge variant="outline" className="mr-2">✓</Badge>
                  Online-Bestellung
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <Badge variant="outline" className="mr-2">✓</Badge>
                  Express-Lieferung verfügbar
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white hover:shadow-xl transition-shadow damascus-card">
            <CardHeader>
              <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center mb-4">
                <MapPin className="text-primary text-2xl" />
              </div>
              <CardTitle className="font-playfair text-2xl text-primary">Event-Location</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700 mb-6">
                Mieten Sie unseren stilvollen Eventraum für Ihre besonderen Anlässe. 
                Perfekt für private Feiern und kleinere Geschäftsveranstaltungen.
              </p>
              <div className="space-y-2">
                <div className="flex items-center text-sm text-gray-600">
                  <Badge variant="outline" className="mr-2">✓</Badge>
                  Bis zu 50 Personen
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <Badge variant="outline" className="mr-2">✓</Badge>
                  Vollservice-Catering
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <Badge variant="outline" className="mr-2">✓</Badge>
                  Orientalische Dekoration
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <Badge variant="outline" className="mr-2">✓</Badge>
                  Flexible Buchungszeiten
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white hover:shadow-xl transition-shadow">
            <CardHeader>
              <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center mb-4">
                <ShoppingBag className="text-white text-2xl" />
              </div>
              <CardTitle className="font-playfair text-2xl text-primary">Spezielle Services</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700 mb-6">
                Darüber hinaus bieten wir individuelle Services für besondere Wünsche 
                und maßgeschneiderte kulinarische Erlebnisse.
              </p>
              <div className="space-y-2">
                <div className="flex items-center text-sm text-gray-600">
                  <Badge variant="outline" className="mr-2">✓</Badge>
                  Koch-Workshops
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <Badge variant="outline" className="mr-2">✓</Badge>
                  Thematische Menüs
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <Badge variant="outline" className="mr-2">✓</Badge>
                  Live-Cooking Shows
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <Badge variant="outline" className="mr-2">✓</Badge>
                  Vegetarische/Vegane Optionen
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="mt-16 bg-white shadow-lg">
          <CardContent className="p-8">
            <div className="text-center">
              <h4 className="font-playfair text-2xl font-semibold text-primary mb-8">Zusätzliche Services</h4>
              <div className="grid md:grid-cols-4 gap-6">
                <div className="text-center">
                  <Truck className="text-primary text-3xl mb-3 mx-auto" />
                  <h5 className="font-semibold text-gray-800 mb-2">Lieferservice</h5>
                  <p className="text-sm text-gray-600">Frische Lieferung direkt zu Ihrem Event</p>
                </div>
                <div className="text-center">
                  <UtensilsCrossed className="text-primary text-3xl mb-3 mx-auto" />
                  <h5 className="font-semibold text-gray-800 mb-2">Service-Personal</h5>
                  <p className="text-sm text-gray-600">Professionelle Bedienung für Ihr Event</p>
                </div>
                <div className="text-center">
                  <Coffee className="text-primary text-3xl mb-3 mx-auto" />
                  <h5 className="font-semibold text-gray-800 mb-2">Getränkeservice</h5>
                  <p className="text-sm text-gray-600">Orientalische Tees und alkoholfreie Getränke</p>
                </div>
                <div className="text-center">
                  <Flower className="text-primary text-3xl mb-3 mx-auto" />
                  <h5 className="font-semibold text-gray-800 mb-2">Dekoration</h5>
                  <p className="text-sm text-gray-600">Authentische orientalische Tischdekoration</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
