import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { MapPin, Phone, Mail, Clock, TrainFront, Bus, Car } from "lucide-react";

export default function Contact() {
  return (
    <section id="contact" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12">
          <div>
            <h3 className="font-playfair text-4xl font-bold text-primary mb-6">Kontakt & Standort</h3>
            <p className="text-lg text-gray-700 mb-8">
              Besuchen Sie uns in unserer Küche oder kontaktieren Sie uns für eine persönliche Beratung. 
              Wir freuen uns darauf, mit Ihnen über Ihr nächstes Event zu sprechen.
            </p>

            <div className="space-y-6">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
                  <MapPin className="text-white w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-semibold text-primary mb-1">Adresse</h4>
                  <p className="text-gray-700">
                    Benzstraße 31<br />
                    70327 Stuttgart<br />
                    Deutschland
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-secondary rounded-full flex items-center justify-center flex-shrink-0">
                  <Phone className="text-primary w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-semibold text-primary mb-1">Telefon</h4>
                  <p className="text-gray-700">
                    <a href="tel:+4917643543612" className="hover:text-primary transition-colors">
                      017643543612
                    </a><br />
                    <span className="text-sm text-gray-500">Mo-Sa: 09:00 - 18:00 Uhr</span>
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-accent rounded-full flex items-center justify-center flex-shrink-0">
                  <Mail className="text-white w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-semibold text-primary mb-1">E-Mail</h4>
                  <p className="text-gray-700">
                    <a href="mailto:info@damaskus-catering.de" className="hover:text-primary transition-colors">
                      info@damaskus-catering.de
                    </a><br />
                    <a href="mailto:events@damaskus-catering.de" className="hover:text-primary transition-colors">
                      events@damaskus-catering.de
                    </a>
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-olive rounded-full flex items-center justify-center flex-shrink-0">
                  <Clock className="text-white w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-semibold text-primary mb-1">Öffnungszeiten</h4>
                  <p className="text-gray-700">
                    Montag - Freitag: 09:00 - 18:00 Uhr<br />
                    Samstag: 10:00 - 16:00 Uhr<br />
                    Sonntag: Nach Vereinbarung
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-8 pt-8 border-t border-gray-200">
              <h4 className="font-semibold text-primary mb-4">Folgen Sie uns</h4>
              <div className="flex space-x-4">
                <Button variant="outline" size="icon" className="w-10 h-10 rounded-full border-primary text-primary hover:bg-primary hover:text-white">
                  📘
                </Button>
                <Button variant="outline" size="icon" className="w-10 h-10 rounded-full border-primary text-primary hover:bg-primary hover:text-white">
                  📷
                </Button>
                <Button variant="outline" size="icon" className="w-10 h-10 rounded-full border-primary text-primary hover:bg-primary hover:text-white">
                  💼
                </Button>
                <Button variant="outline" size="icon" className="w-10 h-10 rounded-full border-primary text-primary hover:bg-primary hover:text-white">
                  💬
                </Button>
              </div>
            </div>
          </div>

          <div>
            <div className="bg-gray-200 rounded-xl h-96 flex items-center justify-center mb-8">
              <div className="text-center text-gray-500">
                <MapPin className="w-16 h-16 mx-auto mb-4" />
                <p className="text-lg font-semibold">Google Maps Integration</p>
                <p className="text-sm">Benzstraße 31, Stuttgart</p>
                <Button className="mt-4 bg-primary text-white hover:bg-primary/90">
                  Route Planen
                </Button>
              </div>
            </div>

            <Card className="bg-beige">
              <CardContent className="p-6">
                <h4 className="font-playfair text-xl font-semibold text-primary mb-4">Anfahrt & Parken</h4>
                <div className="space-y-3 text-gray-700">
                  <div className="flex items-center">
                    <TrainFront className="text-primary mr-3 w-5 h-5" />
                    <span>S-Bahn: Linie S1, S2, S3 - Haltestelle "Stuttgart-Untertürkheim"</span>
                  </div>
                  <div className="flex items-center">
                    <Bus className="text-primary mr-3 w-5 h-5" />
                    <span>Bus: Linie 61, 62 - Haltestelle "Benzstraße"</span>
                  </div>
                  <div className="flex items-center">
                    <Car className="text-primary mr-3 w-5 h-5" />
                    <span>Kostenlose Parkplätze vor dem Haus verfügbar</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
