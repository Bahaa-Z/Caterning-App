import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Download } from "lucide-react";
import type { MenuItem } from "@shared/schema";

export default function MenuShowcase() {
  const [activeCategory, setActiveCategory] = useState("all");

  const { data: menuItems, isLoading, error } = useQuery<MenuItem[]>({
    queryKey: ["/api/menu"],
  });

  const categories = [
    { id: "all", label: "Alle Spezialitäten" },
    { id: "appetizers", label: "Vorspeisen" },
    { id: "mains", label: "Hauptgerichte" },
    { id: "desserts", label: "Süßspeisen" },
  ];

  const filteredItems = menuItems?.filter(
    item => activeCategory === "all" || item.category === activeCategory
  ) || [];

  if (error) {
    return (
      <section id="menu" className="py-20 bg-white">
        <div className="container mx-auto px-4 text-center">
          <p className="text-red-600">Fehler beim Laden der Speisekarte</p>
        </div>
      </section>
    );
  }

  return (
    <section id="menu" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h3 className="font-playfair text-4xl font-bold text-primary mb-4">Unsere Spezialitäten</h3>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto">
            Entdecken Sie die Vielfalt der authentischen syrischen Küche – von traditionellen 
            Vorspeisen bis zu köstlichen Hauptgerichten und orientalischen Süßspeisen.
          </p>
        </div>

        {/* Menu Categories */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((category) => (
            <Button
              key={category.id}
              onClick={() => setActiveCategory(category.id)}
              variant={activeCategory === category.id ? "default" : "outline"}
              className={`px-6 py-3 font-semibold transition-colors ${
                activeCategory === category.id
                  ? "bg-primary text-white"
                  : "bg-gray-200 text-gray-700 hover:bg-gray-300"
              }`}
            >
              {category.label}
            </Button>
          ))}
        </div>

        {/* Menu Items Grid */}
        {isLoading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="bg-beige animate-pulse">
                <div className="w-full h-48 bg-gray-300"></div>
                <CardContent className="p-6">
                  <div className="h-6 bg-gray-300 rounded mb-2"></div>
                  <div className="h-4 bg-gray-300 rounded mb-4"></div>
                  <div className="h-4 bg-gray-300 rounded w-24"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredItems.map((item) => (
              <Card key={item.id} className="bg-beige hover:shadow-xl transition-shadow">
                <img 
                  src={item.imageUrl || "https://images.unsplash.com/photo-1567620905732-2d1ec7ab7445?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"} 
                  alt={item.name} 
                  className="w-full h-48 object-cover rounded-t-lg"
                />
                <CardContent className="p-6">
                  <h4 className="font-playfair text-xl font-semibold text-primary mb-2">{item.name}</h4>
                  <p className="text-gray-700 text-sm mb-4">{item.description}</p>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-secondary font-bold">{item.price}</span>
                    <div className="flex gap-2">
                      {item.isVegan && (
                        <Badge variant="secondary" className="bg-olive text-white">Vegan</Badge>
                      )}
                      {item.isGlutenFree && (
                        <Badge variant="secondary" className="bg-olive text-white">Glutenfrei</Badge>
                      )}
                      {item.featured && (
                        <Badge className="bg-primary text-white">Bestseller</Badge>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        <div className="text-center mt-12">
          <Button className="bg-primary text-white px-8 py-4 text-lg font-semibold hover:bg-primary/90">
            <Download className="w-5 h-5 mr-2" />
            Komplette Speisekarte Herunterladen
          </Button>
        </div>
      </div>
    </section>
  );
}
