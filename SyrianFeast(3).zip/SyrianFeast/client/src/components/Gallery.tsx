import { Button } from "@/components/ui/button";
import { Images } from "lucide-react";

export default function Gallery() {
  const galleryImages = [
    {
      src: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
      alt: "Bunte syrische Gewürze"
    },
    {
      src: "https://images.unsplash.com/photo-1555244162-803834f70033?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
      alt: "Elegante Catering-Präsentation"
    },
    {
      src: "https://images.unsplash.com/photo-1509440159596-0249088772ff?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
      alt: "Frisches syrisches Fladenbrot"
    },
    {
      src: "https://images.unsplash.com/photo-1519225421980-715cb0215aed?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
      alt: "Hochzeitsfeier mit syrischem Catering"
    },
    {
      src: "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
      alt: "Professionelle Küchenarbeit"
    },
    {
      src: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
      alt: "Orientalische Süßspeisen"
    },
    {
      src: "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
      alt: "Firmen-Mittagessen Setup"
    },
    {
      src: "https://images.unsplash.com/photo-1544787219-7f47ccb76574?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
      alt: "Traditioneller arabischer Tee-Service"
    }
  ];

  return (
    <section id="gallery" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h3 className="font-playfair text-4xl font-bold text-primary mb-4">Unsere Kulinarischen Kunstwerke</h3>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto">
            Lassen Sie sich von unseren authentischen syrischen Spezialitäten und erfolgreichen Events inspirieren
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {galleryImages.map((image, index) => (
            <img 
              key={index}
              src={image.src}
              alt={image.alt}
              className="rounded-xl shadow-lg hover:shadow-xl transition-shadow cursor-pointer w-full h-48 object-cover"
              onClick={() => {
                // TODO: Implement lightbox functionality
                console.log('Open lightbox for:', image.alt);
              }}
            />
          ))}
        </div>

        <div className="text-center mt-12">
          <Button className="bg-secondary text-primary px-8 py-4 text-lg font-semibold hover:bg-secondary/90">
            <Images className="w-5 h-5 mr-2" />
            Vollständige Galerie Ansehen
          </Button>
        </div>
      </div>
    </section>
  );
}
