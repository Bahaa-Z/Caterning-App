import { Card, CardContent } from "@/components/ui/card";
import { Star } from "lucide-react";

export default function Testimonials() {
  const testimonials = [
    {
      name: "Sandra Müller",
      role: "Geschäftsführerin, TechCorp GmbH",
      image: "https://images.unsplash.com/photo-1494790108755-2616b612b786?ixlib=rb-4.0.3&auto=format&fit=crop&w=60&h=60",
      text: "Das Damaskus Catering hat unsere Firmenfeier zu einem unvergesslichen Erlebnis gemacht. Die Qualität der Speisen und die Gastfreundschaft waren außergewöhnlich!",
      rating: 5
    },
    {
      name: "Michael & Lisa Weber",
      role: "Brautpaar",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=60&h=60",
      text: "Für unsere Hochzeit wollten wir etwas Besonderes. Das syrische Menü war ein absolutes Highlight und alle Gäste waren begeistert von den authentischen Aromen.",
      rating: 5
    },
    {
      name: "Petra Schmidt",
      role: "Event-Managerin",
      image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&auto=format&fit=crop&w=60&h=60",
      text: "Professionell, pünktlich und unglaublich lecker! Das Team von Damaskus Catering hat unsere Erwartungen weit übertroffen. Absolut empfehlenswert!",
      rating: 5
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h3 className="font-playfair text-4xl font-bold text-primary mb-4">Was Unsere Kunden Sagen</h3>
          <p className="text-xl text-gray-700">Über 500 zufriedene Kunden vertrauen auf unsere Qualität</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="bg-beige shadow-lg">
              <CardContent className="p-8">
                <div className="flex items-center mb-6">
                  <div className="flex text-secondary text-xl">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 fill-current" />
                    ))}
                  </div>
                </div>
                <p className="text-gray-700 italic mb-6">"{testimonial.text}"</p>
                <div className="flex items-center">
                  <img 
                    src={testimonial.image} 
                    alt={testimonial.name} 
                    className="w-12 h-12 rounded-full object-cover mr-4"
                  />
                  <div>
                    <h5 className="font-semibold text-primary">{testimonial.name}</h5>
                    <p className="text-sm text-gray-600">{testimonial.role}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
