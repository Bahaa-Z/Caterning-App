import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Clock, Calculator, Handshake, Send } from "lucide-react";
import { insertInquirySchema } from "@shared/schema";

const formSchema = insertInquirySchema.extend({
  acceptPrivacy: z.boolean().refine(val => val === true, {
    message: "Sie müssen der Datenschutzerklärung zustimmen"
  })
});

type FormData = z.infer<typeof formSchema>;

export default function BookingForm() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      eventType: "",
      guestCount: 10,
      eventDate: "",
      budget: "",
      message: "",
      language: "de",
      acceptPrivacy: false
    }
  });

  const submitInquiry = useMutation({
    mutationFn: async (data: Omit<FormData, 'acceptPrivacy'>) => {
      return apiRequest("POST", "/api/inquiries", data);
    },
    onSuccess: () => {
      toast({
        title: "Anfrage gesendet!",
        description: "Vielen Dank für Ihre Anfrage. Wir melden uns innerhalb von 24 Stunden bei Ihnen.",
      });
      form.reset();
      queryClient.invalidateQueries({ queryKey: ["/api/inquiries"] });
    },
    onError: () => {
      toast({
        title: "Fehler",
        description: "Ihre Anfrage konnte nicht gesendet werden. Bitte versuchen Sie es erneut.",
        variant: "destructive",
      });
    },
    onSettled: () => {
      setIsSubmitting(false);
    }
  });

  const onSubmit = (data: FormData) => {
    setIsSubmitting(true);
    const { acceptPrivacy, ...inquiryData } = data;
    submitInquiry.mutate(inquiryData);
  };

  return (
    <section id="booking" className="py-20 bg-gradient-to-br from-primary to-red-800 text-white">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h3 className="font-playfair text-4xl font-bold mb-4">Planen Sie Ihr Event mit Uns</h3>
            <p className="text-xl text-gray-100">
              Lassen Sie uns gemeinsam Ihr unvergessliches kulinarisches Erlebnis schaffen. 
              Füllen Sie das Formular aus und wir melden uns innerhalb von 24 Stunden.
            </p>
          </div>

          <Card className="bg-white bg-opacity-10 backdrop-blur-lg border-white border-opacity-30">
            <CardContent className="p-8">
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="grid md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="firstName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white font-semibold">Vorname *</FormLabel>
                        <FormControl>
                          <Input 
                            {...field} 
                            placeholder="Ihr Vorname"
                            className="bg-white bg-opacity-20 border-white border-opacity-30 text-white placeholder-gray-300 focus:ring-2 focus:ring-secondary"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="lastName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white font-semibold">Nachname *</FormLabel>
                        <FormControl>
                          <Input 
                            {...field} 
                            placeholder="Ihr Nachname"
                            className="bg-white bg-opacity-20 border-white border-opacity-30 text-white placeholder-gray-300 focus:ring-2 focus:ring-secondary"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white font-semibold">E-Mail *</FormLabel>
                        <FormControl>
                          <Input 
                            {...field} 
                            type="email"
                            placeholder="ihre@email.de"
                            className="bg-white bg-opacity-20 border-white border-opacity-30 text-white placeholder-gray-300 focus:ring-2 focus:ring-secondary"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white font-semibold">Telefon</FormLabel>
                        <FormControl>
                          <Input 
                            {...field} 
                            type="tel"
                            placeholder="+49 XXX XXXXXXX"
                            className="bg-white bg-opacity-20 border-white border-opacity-30 text-white placeholder-gray-300 focus:ring-2 focus:ring-secondary"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="eventType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white font-semibold">Event-Typ *</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="bg-white bg-opacity-20 border-white border-opacity-30 text-white focus:ring-2 focus:ring-secondary">
                              <SelectValue placeholder="Bitte wählen" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="corporate">Firmenevent</SelectItem>
                            <SelectItem value="wedding">Hochzeit</SelectItem>
                            <SelectItem value="private">Private Feier</SelectItem>
                            <SelectItem value="other">Sonstiges</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="guestCount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white font-semibold">Anzahl Gäste *</FormLabel>
                        <FormControl>
                          <Input 
                            {...field} 
                            type="number"
                            min="10"
                            placeholder="Anzahl Personen"
                            className="bg-white bg-opacity-20 border-white border-opacity-30 text-white placeholder-gray-300 focus:ring-2 focus:ring-secondary"
                            onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="eventDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white font-semibold">Event-Datum</FormLabel>
                        <FormControl>
                          <Input 
                            {...field} 
                            type="date"
                            className="bg-white bg-opacity-20 border-white border-opacity-30 text-white focus:ring-2 focus:ring-secondary"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="budget"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white font-semibold">Budget (ca.)</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="bg-white bg-opacity-20 border-white border-opacity-30 text-white focus:ring-2 focus:ring-secondary">
                              <SelectValue placeholder="Budget wählen" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="500-1000">500€ - 1.000€</SelectItem>
                            <SelectItem value="1000-2500">1.000€ - 2.500€</SelectItem>
                            <SelectItem value="2500-5000">2.500€ - 5.000€</SelectItem>
                            <SelectItem value="5000+">Über 5.000€</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="message"
                    render={({ field }) => (
                      <FormItem className="md:col-span-2">
                        <FormLabel className="text-white font-semibold">Ihre Nachricht</FormLabel>
                        <FormControl>
                          <Textarea 
                            {...field} 
                            rows={4}
                            placeholder="Erzählen Sie uns mehr über Ihr Event, besondere Wünsche oder Anforderungen..."
                            className="bg-white bg-opacity-20 border-white border-opacity-30 text-white placeholder-gray-300 focus:ring-2 focus:ring-secondary resize-none"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="acceptPrivacy"
                    render={({ field }) => (
                      <FormItem className="md:col-span-2">
                        <div className="flex items-center space-x-3">
                          <FormControl>
                            <Checkbox 
                              checked={field.value}
                              onCheckedChange={field.onChange}
                              className="bg-white bg-opacity-20 border-white"
                            />
                          </FormControl>
                          <FormLabel className="text-sm text-white">
                            Ich stimme der Verarbeitung meiner Daten gemäß{" "}
                            <button type="button" className="text-secondary underline hover:text-secondary/80">
                              Datenschutzerklärung
                            </button>{" "}
                            zu *
                          </FormLabel>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="md:col-span-2 text-center">
                    <Button 
                      type="submit" 
                      disabled={isSubmitting}
                      className="bg-secondary text-primary px-12 py-4 text-lg font-bold hover:bg-secondary/90 transform hover:scale-105 transition-all"
                    >
                      <Send className="w-5 h-5 mr-2" />
                      {isSubmitting ? "Wird gesendet..." : "Kostenlose Beratung Anfragen"}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>

          <div className="grid md:grid-cols-3 gap-6 mt-12 text-center">
            <div>
              <Clock className="text-secondary text-3xl mb-3 mx-auto" />
              <h4 className="font-semibold mb-2">Schnelle Antwort</h4>
              <p className="text-gray-100 text-sm">Rückmeldung innerhalb von 24 Stunden</p>
            </div>
            <div>
              <Calculator className="text-secondary text-3xl mb-3 mx-auto" />
              <h4 className="font-semibold mb-2">Kostenlose Beratung</h4>
              <p className="text-gray-100 text-sm">Unverbindliches Angebot mit fairen Preisen</p>
            </div>
            <div>
              <Handshake className="text-secondary text-3xl mb-3 mx-auto" />
              <h4 className="font-semibold mb-2">Persönlicher Service</h4>
              <p className="text-gray-100 text-sm">Individuelle Betreuung von A bis Z</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
