import { Button } from "@/components/ui/button";
import { Calendar, Play, Users, Award, Heart } from "lucide-react";

export default function Hero() {
  const scrollToBooking = () => {
    const element = document.getElementById('booking');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToAbout = () => {
    const element = document.getElementById('about');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="pt-20 bg-gradient-to-r from-primary to-red-700 text-white relative overflow-hidden">
      <div className="absolute inset-0 bg-black bg-opacity-30"></div>
      <div 
        className="absolute inset-0 bg-cover bg-center" 
        style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1567620905732-2d1ec7ab7445?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080')"
        }}
      ></div>
      
      <div className="container mx-auto px-4 py-24 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="font-playfair text-5xl md:text-7xl font-bold mb-6">
            Authentische Syrische
            <span className="text-secondary block">Catering-Kunst</span>
          </h2>
          <p className="text-xl md:text-2xl mb-8 text-gray-100">
            Von traditionellen Familienrezepten zu unvergesslichen Geschmackserlebnissen – 
            wir bringen die Wärme und Gastfreundschaft Syriens zu Ihren besonderen Anlässen.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              onClick={scrollToBooking}
              className="bg-secondary text-primary px-8 py-4 text-lg font-semibold hover:bg-secondary/90 transform hover:scale-105 transition-all"
            >
              <Calendar className="w-5 h-5 mr-2" />
              Event Planen
            </Button>
            <Button 
              variant="outline"
              onClick={scrollToAbout}
              className="border-2 border-white text-white px-8 py-4 text-lg font-semibold hover:bg-white hover:text-primary transition-all"
            >
              <Play className="w-5 h-5 mr-2" />
              Unsere Geschichte
            </Button>
          </div>
        </div>
      </div>

      {/* Floating Cards */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 hidden lg:flex space-x-6">
        <div className="bg-white bg-opacity-20 backdrop-blur-lg rounded-lg p-4 text-center">
          <Users className="text-secondary text-2xl mb-2 mx-auto" />
          <p className="text-sm font-semibold">500+ Events</p>
        </div>
        <div className="bg-white bg-opacity-20 backdrop-blur-lg rounded-lg p-4 text-center">
          <Award className="text-secondary text-2xl mb-2 mx-auto" />
          <p className="text-sm font-semibold">Authentische Rezepte</p>
        </div>
        <div className="bg-white bg-opacity-20 backdrop-blur-lg rounded-lg p-4 text-center">
          <Heart className="text-secondary text-2xl mb-2 mx-auto" />
          <p className="text-sm font-semibold">100% Halal</p>
        </div>
      </div>
    </section>
  );
}
