import { Badge } from "@/components/ui/badge";

export default function About() {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h3 className="font-playfair text-4xl font-bold text-primary mb-6 relative damascus-border">
              Eine Kulinarische Reise von Damaskus nach Stuttgart
            </h3>
            <div className="damascus-ornament"></div>
            <p className="text-lg text-gray-700 mb-6">
              Damaskus Catering ist ein junges, dynamisches Unternehmen mit einer großen Leidenschaft für 
              die authentische syrische Küche. Unsere Gründer bringen umfangreiche Erfahrungen im 
              Eventmanagement und in der professionellen Küche mit und haben sich den Traum erfüllt, 
              die Geschmäcker und Traditionen Syriens nach Stuttgart zu bringen.
            </p>
            <p className="text-lg text-gray-700 mb-6">
              Mit traditionellen Familienrezepten und modernem Catering-Service schaffen wir unvergessliche 
              kulinarische Erlebnisse. Unsere Spezialität liegt in der perfekten Kombination aus 
              authentischen Aromen und professionellem Service für jeden Anlass.
            </p>
            <p className="text-lg text-gray-700 mb-8">
              Bei Damaskus Catering verstehen wir, dass jedes Event einzigartig ist. Ob Firmenfeier, 
              Hochzeit oder private Feier – wir kreieren maßgeschneiderte kulinarische Erlebnisse mit 
              der Wärme und Gastfreundschaft, für die Syrien bekannt ist.
            </p>

            <div className="grid grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-3xl font-bold text-primary">10+</div>
                <div className="text-sm text-gray-600">Jahre Küchenerfahrung</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary">150+</div>
                <div className="text-sm text-gray-600">Erfolgreiche Events</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary">100%</div>
                <div className="text-sm text-gray-600">Authentische Rezepte</div>
              </div>
            </div>
          </div>
          
          <div className="relative">
            <img 
              src="https://images.unsplash.com/photo-1596040033229-a9821ebd058d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
              alt="Syrische Gewürze und Zutaten" 
              className="rounded-xl shadow-lg w-full h-auto"
            />
            <div className="absolute -bottom-6 -right-6 bg-secondary p-6 rounded-xl shadow-lg text-primary">
              <Badge className="text-3xl mb-2 bg-transparent border-none p-0">🎖️</Badge>
              <p className="font-semibold">Halal Zertifiziert</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
