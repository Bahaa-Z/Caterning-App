import { Utensils } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-16">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                <Utensils className="text-white w-5 h-5" />
              </div>
              <div>
                <h4 className="font-playfair text-xl font-bold text-primary">Damaskus Catering</h4>
              </div>
            </div>
            <p className="text-gray-300 mb-6">
              Authentische syrische Küche für unvergessliche Events. 
              Seit über 15 Jahren Ihr Partner für exzellentes Catering in Stuttgart.
            </p>
            <div className="flex space-x-3">
              <Button variant="outline" size="icon" className="w-8 h-8 rounded-full border-primary text-primary hover:bg-primary hover:text-white">
                📘
              </Button>
              <Button variant="outline" size="icon" className="w-8 h-8 rounded-full border-primary text-primary hover:bg-primary hover:text-white">
                📷
              </Button>
              <Button variant="outline" size="icon" className="w-8 h-8 rounded-full border-primary text-primary hover:bg-primary hover:text-white">
                💼
              </Button>
            </div>
          </div>

          <div>
            <h5 className="font-semibold text-lg mb-6">Services</h5>
            <ul className="space-y-3 text-gray-300">
              <li><button className="hover:text-primary transition-colors text-left">Firmencatering</button></li>
              <li><button className="hover:text-primary transition-colors text-left">Hochzeitscatering</button></li>
              <li><button className="hover:text-primary transition-colors text-left">Private Events</button></li>
              <li><button className="hover:text-primary transition-colors text-left">Lieferservice</button></li>
              <li><button className="hover:text-primary transition-colors text-left">Eventplanung</button></li>
            </ul>
          </div>

          <div>
            <h5 className="font-semibold text-lg mb-6">Speisekarte</h5>
            <ul className="space-y-3 text-gray-300">
              <li><button className="hover:text-primary transition-colors text-left">Vorspeisen & Mezze</button></li>
              <li><button className="hover:text-primary transition-colors text-left">Hauptgerichte</button></li>
              <li><button className="hover:text-primary transition-colors text-left">Vegetarische Optionen</button></li>
              <li><button className="hover:text-primary transition-colors text-left">Orientalische Süßspeisen</button></li>
              <li><button className="hover:text-primary transition-colors text-left">Getränke</button></li>
            </ul>
          </div>

          <div>
            <h5 className="font-semibold text-lg mb-6">Kontakt</h5>
            <div className="space-y-3 text-gray-300">
              <div className="flex items-start">
                <span className="text-primary mr-3">📍</span>
                <span className="text-sm">
                  Benzstraße 31<br />
                  70327 Stuttgart
                </span>
              </div>
              <div className="flex items-center">
                <span className="text-primary mr-3">📞</span>
                <a href="tel:+4917643543612" className="text-sm hover:text-primary transition-colors">
                  017643543612
                </a>
              </div>
              <div className="flex items-center">
                <span className="text-primary mr-3">✉️</span>
                <a href="mailto:info@damaskus-catering.de" className="text-sm hover:text-primary transition-colors">
                  info@damaskus-catering.de
                </a>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm mb-4 md:mb-0">
              © 2024 Damaskus Catering. Alle Rechte vorbehalten.
            </p>
            <div className="flex space-x-6 text-sm text-gray-400">
              <button className="hover:text-primary transition-colors">Impressum</button>
              <button className="hover:text-primary transition-colors">Datenschutz</button>
              <button className="hover:text-primary transition-colors">AGB</button>
              <button className="hover:text-primary transition-colors">Cookies</button>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
