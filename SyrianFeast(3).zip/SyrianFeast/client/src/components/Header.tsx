import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Phone, Menu, Utensils } from "lucide-react";

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  return (
    <header className="bg-white shadow-lg fixed w-full top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
              <Utensils className="text-white text-xl" />
            </div>
            <div>
              <h1 className="font-playfair text-2xl font-bold text-primary">Damaskus Catering</h1>
              <p className="text-sm text-gray-600">Authentische Syrische Küche</p>
            </div>
          </div>
          
          <nav className="hidden lg:flex space-x-8">
            <button onClick={() => scrollToSection('home')} className="text-gray-700 hover:text-primary transition-colors">
              Startseite
            </button>
            <button onClick={() => scrollToSection('about')} className="text-gray-700 hover:text-primary transition-colors">
              Über Uns
            </button>
            <button onClick={() => scrollToSection('services')} className="text-gray-700 hover:text-primary transition-colors">
              Leistungen
            </button>
            <button onClick={() => scrollToSection('menu')} className="text-gray-700 hover:text-primary transition-colors">
              Speisekarte
            </button>
            <button onClick={() => scrollToSection('gallery')} className="text-gray-700 hover:text-primary transition-colors">
              Galerie
            </button>
            <button onClick={() => scrollToSection('contact')} className="text-gray-700 hover:text-primary transition-colors">
              Kontakt
            </button>
          </nav>

          <div className="flex items-center space-x-4">
            <div className="hidden md:flex space-x-2">
              <Button variant="outline" size="sm" className="text-xs">DE</Button>
              <Button variant="outline" size="sm" className="text-xs">AR</Button>
            </div>
            <Button 
              onClick={() => scrollToSection('booking')}
              className="bg-primary text-white hover:bg-primary/90"
            >
              <Phone className="w-4 h-4 mr-2" />
              Jetzt Anfragen
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="lg:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              <Menu className="w-5 h-5" />
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="lg:hidden border-t border-gray-200 py-4">
            <nav className="flex flex-col space-y-2">
              <button onClick={() => scrollToSection('home')} className="text-left py-2 text-gray-700 hover:text-primary">
                Startseite
              </button>
              <button onClick={() => scrollToSection('about')} className="text-left py-2 text-gray-700 hover:text-primary">
                Über Uns
              </button>
              <button onClick={() => scrollToSection('services')} className="text-left py-2 text-gray-700 hover:text-primary">
                Leistungen
              </button>
              <button onClick={() => scrollToSection('menu')} className="text-left py-2 text-gray-700 hover:text-primary">
                Speisekarte
              </button>
              <button onClick={() => scrollToSection('gallery')} className="text-left py-2 text-gray-700 hover:text-primary">
                Galerie
              </button>
              <button onClick={() => scrollToSection('contact')} className="text-left py-2 text-gray-700 hover:text-primary">
                Kontakt
              </button>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
