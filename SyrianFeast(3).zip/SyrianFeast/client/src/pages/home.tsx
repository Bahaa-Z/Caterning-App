import Header from "@/components/Header";
import Hero from "@/components/Hero";
import About from "@/components/About";
import Services from "@/components/Services";
import MenuShowcase from "@/components/MenuShowcase";
import WeeklySpecials from "@/components/WeeklySpecials";
import Gallery from "@/components/Gallery";
import Testimonials from "@/components/Testimonials";
import BookingForm from "@/components/BookingForm";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-cream">
      <Header />
      <Hero />
      <About />
      <Services />
      <MenuShowcase />
      <WeeklySpecials />
      <Gallery />
      <Testimonials />
      <BookingForm />
      <Contact />
      <Footer />
    </div>
  );
}
