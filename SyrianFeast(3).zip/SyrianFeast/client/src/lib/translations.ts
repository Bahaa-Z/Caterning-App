export const translations = {
  de: {
    nav: {
      home: "Startseite",
      about: "Über Uns",
      services: "Leistungen",
      menu: "Speisekarte",
      gallery: "Galerie",
      contact: "Kontakt",
      inquireNow: "Jetzt Anfragen"
    },
    hero: {
      title: "Authentische Syrische",
      titleAccent: "Catering-Kunst",
      subtitle: "Von traditionellen Familienrezepten zu unvergesslichen Geschmackserlebnissen – wir bringen die Wärme und Gastfreundschaft Syriens zu Ihren besonderen Anlässen.",
      planEvent: "Event Planen",
      ourStory: "Unsere Geschichte"
    },
    about: {
      title: "Eine Kulinarische Reise von Damaskus nach Stuttgart",
      description1: "Seit über 15 Jahren bringen wir die authentischen Aromen und die herzliche Gastfreundschaft Syriens nach Deutschland. Unsere Familienrezepte, überliefert über Generationen, werden mit höchster Sorgfalt und den besten regionalen sowie importierten Zutaten zubereitet.",
      description2: "Bei Damaskus Catering verstehen wir, dass jedes Event einzigartig ist. Ob Firmenfeier, Hochzeit oder private Feier – wir kreieren maßgeschneiderte kulinarische Erlebnisse, die Ihre Gäste verzaubern werden.",
      chefs: "Ahmad & Fatima Al-Rashid",
      chefsTitle: "Gründer & Küchenchefs",
      chefsQuote: "Mit Liebe kochen, mit Stolz servieren",
      experience: "Jahre Erfahrung",
      events: "Erfolgreiche Events",
      satisfaction: "Kundenzufriedenheit"
    },
    services: {
      title: "Unsere Catering-Leistungen",
      subtitle: "Von intimen Familienfeiern bis zu großen Firmenevents – wir bieten maßgeschneiderte kulinarische Lösungen für jeden Anlass.",
      corporate: {
        title: "Firmencatering",
        description: "Beeindrucken Sie Ihre Geschäftspartner mit authentischen syrischen Spezialitäten. Von Business-Lunches bis zu großen Firmenevents.",
        features: ["Konferenzverpflegung", "Büro-Mittagessen", "Firmenevents & Feiern", "Produktpräsentationen"]
      },
      wedding: {
        title: "Hochzeitscatering",
        description: "Machen Sie Ihren besonderen Tag unvergesslich mit einem Fest der Sinne. Traditionelle syrische Hochzeitsmenüs mit modernem Touch.",
        features: ["Mehrgängige Festmenüs", "Orientalische Süßspeisen", "Buffet & À-la-carte", "Komplette Eventplanung"]
      },
      private: {
        title: "Private Events",
        description: "Geburtstage, Familienfeier oder besondere Anlässe – wir bringen die Wärme der syrischen Gastfreundschaft zu Ihnen nach Hause.",
        features: ["Geburtstagsfeier", "Familienfeste", "Dinner-Partys", "Religiöse Feiern"]
      },
      additional: {
        title: "Zusätzliche Services",
        delivery: "Lieferservice",
        deliveryDesc: "Frische Lieferung direkt zu Ihrem Event",
        staff: "Service-Personal",
        staffDesc: "Professionelle Bedienung für Ihr Event",
        drinks: "Getränkeservice",
        drinksDesc: "Orientalische Tees und alkoholfreie Getränke",
        decoration: "Dekoration",
        decorationDesc: "Authentische orientalische Tischdekoration"
      }
    },
    common: {
      loading: "Lädt...",
      error: "Ein Fehler ist aufgetreten",
      success: "Erfolgreich übermittelt",
      required: "Pflichtfeld"
    }
  },
  ar: {
    nav: {
      home: "الرئيسية",
      about: "من نحن",
      services: "خدماتنا",
      menu: "قائمة الطعام",
      gallery: "المعرض",
      contact: "اتصل بنا",
      inquireNow: "استفسر الآن"
    },
    hero: {
      title: "فن تقديم الطعام",
      titleAccent: "السوري الأصيل",
      subtitle: "من وصفات العائلة التقليدية إلى تجارب طعم لا تُنسى - نجلب دفء وكرم الضيافة السورية إلى مناسباتكم الخاصة.",
      planEvent: "خطط للحدث",
      ourStory: "قصتنا"
    },
    // ... other Arabic translations
    common: {
      loading: "جاري التحميل...",
      error: "حدث خطأ",
      success: "تم الإرسال بنجاح",
      required: "حقل مطلوب"
    }
  }
};

export type Language = keyof typeof translations;
