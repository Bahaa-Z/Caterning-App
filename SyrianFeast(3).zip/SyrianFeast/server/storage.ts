import { type Inquiry, type InsertInquiry, type MenuItem, type InsertMenuItem, type WeeklySpecial, type InsertWeeklySpecial } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Inquiries
  createInquiry(inquiry: InsertInquiry): Promise<Inquiry>;
  getInquiries(): Promise<Inquiry[]>;
  getInquiry(id: string): Promise<Inquiry | undefined>;
  
  // Menu Items
  getMenuItems(): Promise<MenuItem[]>;
  getMenuItemsByCategory(category: string): Promise<MenuItem[]>;
  createMenuItem(item: InsertMenuItem): Promise<MenuItem>;
  
  // Weekly Specials
  getWeeklySpecials(): Promise<WeeklySpecial[]>;
  getActiveWeeklySpecials(): Promise<WeeklySpecial[]>;
  createWeeklySpecial(special: InsertWeeklySpecial): Promise<WeeklySpecial>;
}

export class MemStorage implements IStorage {
  private inquiries: Map<string, Inquiry>;
  private menuItems: Map<string, MenuItem>;
  private weeklySpecials: Map<string, WeeklySpecial>;

  constructor() {
    this.inquiries = new Map();
    this.menuItems = new Map();
    this.weeklySpecials = new Map();
    
    // Initialize with sample menu items
    this.initializeMenuItems();
    this.initializeWeeklySpecials();
  }

  private initializeMenuItems() {
    const items: InsertMenuItem[] = [
      // Appetizers
      {
        name: "Mezze-Variation",
        nameAr: "تشكيلة المزة",
        description: "Traditionelle Auswahl an syrischen Vorspeisen: Hummus, Baba Ghanoush, Tabouleh, marinierte Oliven und frisches Fladenbrot",
        descriptionAr: "تشكيلة تقليدية من المقبلات السورية: حمص، بابا غنوج، تبولة، زيتون متبل وخبز طازج",
        price: "Ab 8,50€ p.P.",
        category: "appetizers",
        isVegan: true,
        isGlutenFree: false,
        imageUrl: "https://images.unsplash.com/photo-1541592106381-b31e9677c0e5?ixlib=rb-4.0.3",
        featured: true,
      },
      {
        name: "Fatayer & Sambousek",
        nameAr: "فطائر وسمبوسك",
        description: "Knusprige Teigtaschen gefüllt mit Spinat, Käse oder Fleisch, gewürzt mit orientalischen Kräutern und Gewürzen",
        descriptionAr: "معجنات مقرمشة محشوة بالسبانخ أو الجبنة أو اللحمة، متبلة بالأعشاب والبهارات الشرقية",
        price: "Ab 6,90€ p.P.",
        category: "appetizers",
        isVegan: false,
        isGlutenFree: false,
        imageUrl: "https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?ixlib=rb-4.0.3",
        featured: true,
      },
      {
        name: "Kibbeh",
        nameAr: "كبة",
        description: "Traditionelle Bulgur-Fleischbällchen mit Pinienkernen und Gewürzen, frittiert bis zur goldenen Perfektion",
        descriptionAr: "كبة تقليدية بالبرغل واللحمة والصنوبر والبهارات، مقلية حتى اللون الذهبي",
        price: "Ab 7,50€ p.P.",
        category: "appetizers",
        isVegan: false,
        isGlutenFree: false,
        imageUrl: "https://images.unsplash.com/photo-1599490659213-e2b9527bd087?ixlib=rb-4.0.3",
      },
      {
        name: "Muhammara",
        nameAr: "محمرة",
        description: "Würzige Walnuss-Paprika-Paste mit Granatapfelsirup und Olivenöl, serviert mit warmem Brot",
        descriptionAr: "عجينة الجوز والفلفل الحار مع دبس الرمان وزيت الزيتون، تُقدم مع الخبز الساخن",
        price: "Ab 6,50€ p.P.",
        category: "appetizers",
        isVegan: true,
        isGlutenFree: true,
        imageUrl: "https://images.unsplash.com/photo-1571091655789-405eb7a3a3a8?ixlib=rb-4.0.3",
      },
      // Main Dishes
      {
        name: "Ouzi - Syrischer Lammbraten",
        nameAr: "أوزي - لحمة خروف سورية",
        description: "Zartes Lammfleisch, stundenlang mit sieben Gewürzen geschmort, serviert mit Safran-Reis und gerösteten Mandeln",
        descriptionAr: "لحمة خروف طرية، مطبوخة لساعات بسبعة بهارات، تُقدم مع أرز بالزعفران واللوز المحمص",
        price: "Ab 18,90€ p.P.",
        category: "mains",
        isVegan: false,
        isGlutenFree: true,
        imageUrl: "https://images.unsplash.com/photo-1574484284002-952d92456975?ixlib=rb-4.0.3",
        featured: true,
      },
      {
        name: "Shish Taouk",
        nameAr: "شيش طاووق",
        description: "Marinierte Hähnchenbrust-Spieße gegrillt, dazu Knoblauch-Joghurt-Sauce, Bulgur-Pilaf und gegrilltes Gemüse",
        descriptionAr: "أسياخ دجاج متبلة ومشوية، مع صلصة الثوم والزبادي، برغل بيلاف وخضار مشوية",
        price: "Ab 14,50€ p.P.",
        category: "mains",
        isVegan: false,
        isGlutenFree: true,
        imageUrl: "https://images.unsplash.com/photo-1529692236671-f1f6cf9683ba?ixlib=rb-4.0.3",
      },
      {
        name: "Mahshi - Gefülltes Gemüse",
        nameAr: "محشي - خضار محشوة",
        description: "Zucchini, Auberginen und Weinblätter gefüllt mit gewürztem Reis, Kräutern und Pinienkernen in Tomaten-Zitronen-Brühe",
        descriptionAr: "كوسا وباذنجان وورق عنب محشوة بالأرز المتبل والأعشاب والصنوبر في مرق الطماطم والليمون",
        price: "Ab 12,90€ p.P.",
        category: "mains",
        isVegan: true,
        isGlutenFree: true,
        imageUrl: "https://images.unsplash.com/photo-1543826173-8ad1e8c00aa3?ixlib=rb-4.0.3",
      },
      {
        name: "Mansaf",
        nameAr: "منسف",
        description: "Traditionelles Festgericht mit zartem Lammfleisch in Joghurt-Sauce, serviert über gewürztem Reis mit Mandeln",
        descriptionAr: "طبق احتفالي تقليدي بلحمة الخروف الطرية في صلصة اللبن، يُقدم فوق الأرز المتبل مع اللوز",
        price: "Ab 19,90€ p.P.",
        category: "mains",
        isVegan: false,
        isGlutenFree: true,
        imageUrl: "https://images.unsplash.com/photo-1551024506-0bccd828d307?ixlib=rb-4.0.3",
        featured: true,
      },
      {
        name: "Shawarma",
        nameAr: "شاورما",
        description: "Würzig mariniertes Fleisch, langsam am Spießgrül gegart, serviert mit Tahini-Sauce und frischem Gemüse",
        descriptionAr: "لحمة متبلة ومشوية على السيخ ببطء، تُقدم مع صلصة الطحينة والخضار الطازجة",
        price: "Ab 13,90€ p.P.",
        category: "mains",
        isVegan: false,
        isGlutenFree: false,
        imageUrl: "https://images.unsplash.com/photo-1529692236671-f1f6cf9683ba?ixlib=rb-4.0.3",
      },
      {
        name: "Maqluba",
        nameAr: "مقلوبة",
        description: "Das 'umgedrehte' Gericht: Geschichteter Reis mit Hühnchen und Gemüse, traditionell serviert und umgestürzt",
        descriptionAr: "الطبق 'المقلوب': أرز مطبوخ بطبقات مع الدجاج والخضار، يُقدم بالطريقة التقليدية مقلوباً",
        price: "Ab 16,50€ p.P.",
        category: "mains",
        isVegan: false,
        isGlutenFree: true,
        imageUrl: "https://images.unsplash.com/photo-1547040063-0c52d4d29ecc?ixlib=rb-4.0.3",
      },
      {
        name: "Freekeh mit Lamm",
        nameAr: "فريكة مع لحمة الخروف",
        description: "Gerösteter grüner Weizen mit zartem Lammfleisch und orientalischen Gewürzen, ein nahrhaftes Traditionsgericht",
        descriptionAr: "قمح أخضر محمص مع لحمة الخروف الطرية والبهارات الشرقية، طبق تقليدي مغذي",
        price: "Ab 15,90€ p.P.",
        category: "mains",
        isVegan: false,
        isGlutenFree: false,
        imageUrl: "https://images.unsplash.com/photo-1555507036-ab794f0ecb24?ixlib=rb-4.0.3",
      },
      // Desserts
      {
        name: "Baklava-Variation",
        nameAr: "تشكيلة بقلاوة",
        description: "Hausgemachte Baklava in verschiedenen Sorten: mit Pistazien, Walnüssen oder Mandeln, getränkt in Honig-Rosenwasser-Sirup",
        descriptionAr: "بقلاوة منزلية بأنواع مختلفة: بالفستق واللوز والجوز، منقوعة بشراب العسل وماء الورد",
        price: "Ab 4,50€ p.P.",
        category: "desserts",
        isVegan: false,
        isGlutenFree: false,
        imageUrl: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?ixlib=rb-4.0.3",
        featured: true,
      },
      {
        name: "Muhallabia",
        nameAr: "مهلبية",
        description: "Cremiger Milchpudding mit Rosenwasser verfeinert, garniert mit Pistazien und kandierten Rosenblättern",
        descriptionAr: "مهلبية كريمية بماء الورد، مزينة بالفستق وبتلات الورد المسكرة",
        price: "Ab 3,90€ p.P.",
        category: "desserts",
        isVegan: false,
        isGlutenFree: true,
        imageUrl: "https://images.unsplash.com/photo-1571091718767-18b5b1457add?ixlib=rb-4.0.3",
      },
      {
        name: "Knafeh",
        nameAr: "كنافة",
        description: "Warme süße Köstlichkeit mit Käse und Kadayif-Teig, getränkt in duftenden Zuckersirup mit Orangenblütenwasser",
        descriptionAr: "حلوى دافئة لذيذة بالجبنة وعجينة الكداييف، منقوعة بالشربات المعطر بماء الزهر",
        price: "Ab 5,90€ p.P.",
        category: "desserts",
        isVegan: false,
        isGlutenFree: false,
        imageUrl: "https://images.unsplash.com/photo-1563051751-9ae3dfee8c5d?ixlib=rb-4.0.3",
        featured: true,
      },
      {
        name: "Mamoul",
        nameAr: "معمول",
        description: "Traditionelle gefüllte Kekse mit Datteln, Feigen oder Nüssen, perfekt zu arabischem Kaffee",
        descriptionAr: "كعك تقليدي محشو بالتمر أو التين أو الجوز، مثالي مع القهوة العربية",
        price: "Ab 4,90€ p.P.",
        category: "desserts",
        isVegan: false,
        isGlutenFree: false,
        imageUrl: "https://images.unsplash.com/photo-1571091718767-18b5b1457add?ixlib=rb-4.0.3",
      },
      {
        name: "Qatayef",
        nameAr: "قطايف",
        description: "Ramadan-Spezialität: Kleine Pfannkuchen gefüllt mit süßem Käse oder Nüssen, frittiert und mit Sirup getränkt",
        descriptionAr: "تخصص رمضان: فطائر صغيرة محشوة بالجبنة الحلوة أو المكسرات، مقلية ومنقوعة بالشربات",
        price: "Ab 5,50€ p.P.",
        category: "desserts",
        isVegan: false,
        isGlutenFree: false,
        imageUrl: "https://images.unsplash.com/photo-1563051751-9ae3dfee8c5d?ixlib=rb-4.0.3",
      },
      {
        name: "Halawet el Jibn",
        nameAr: "حلاوة الجبن",
        description: "Delikate Käse-Rollen gefüllt mit Clotted Cream, garniert mit Pistazien und getränkt in Rosenwasser-Sirup",
        descriptionAr: "لفائف جبنة رقيقة محشوة بالقشطة، مزينة بالفستق ومنقوعة بشراب ماء الورد",
        price: "Ab 6,50€ p.P.",
        category: "desserts",
        isVegan: false,
        isGlutenFree: true,
        imageUrl: "https://images.unsplash.com/photo-1571091718767-18b5b1457add?ixlib=rb-4.0.3",
      },
    ];

    items.forEach(item => {
      const id = randomUUID();
      const menuItem: MenuItem = { ...item, id };
      this.menuItems.set(id, menuItem);
    });
  }

  private initializeWeeklySpecials() {
    const specials: InsertWeeklySpecial[] = [
      {
        name: "Freekeh-Suppe mit Lamm",
        nameAr: "شوربة فريكة مع لحمة الخروف",
        description: "Herzhafte Suppe mit geröstetem grünen Weizen und zartem Lammfleisch",
        descriptionAr: "شوربة شهية بالفريكة المحمصة ولحمة الخروف الطرية",
        price: "13,90€ p.P.",
        availableDays: "Montag - Mittwoch",
        weekStart: "2025-07-28",
        weekEnd: "2025-08-01",
        active: true,
      },
      {
        name: "Kibbeh Nayeh",
        nameAr: "كبة نيئة",
        description: "Traditionelle rohe Kibbeh mit Bulgur, frischen Kräutern und Olivenöl",
        descriptionAr: "كبة نيئة تقليدية بالبرغل والأعشاب الطازجة وزيت الزيتون",
        price: "16,50€ p.P.",
        availableDays: "Donnerstag - Freitag",
        weekStart: "2025-07-28",
        weekEnd: "2025-08-01",
        active: true,
      },
      {
        name: "Knafeh",
        nameAr: "كنافة",
        description: "Süße Köstlichkeit mit Käse und Kadayif-Teig, getränkt in Zuckersirup",
        descriptionAr: "حلوى لذيذة بالجبنة وعجينة الكداييف، منقوعة بالشربات",
        price: "5,90€ p.P.",
        availableDays: "Wochenende",
        weekStart: "2025-07-28",
        weekEnd: "2025-08-01",
        active: true,
      },
    ];

    specials.forEach(special => {
      const id = randomUUID();
      const weeklySpecial: WeeklySpecial = { ...special, id };
      this.weeklySpecials.set(id, weeklySpecial);
    });
  }

  async createInquiry(insertInquiry: InsertInquiry): Promise<Inquiry> {
    const id = randomUUID();
    const inquiry: Inquiry = { 
      ...insertInquiry, 
      id, 
      createdAt: new Date() 
    };
    this.inquiries.set(id, inquiry);
    return inquiry;
  }

  async getInquiries(): Promise<Inquiry[]> {
    return Array.from(this.inquiries.values()).sort((a, b) => 
      new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime()
    );
  }

  async getInquiry(id: string): Promise<Inquiry | undefined> {
    return this.inquiries.get(id);
  }

  async getMenuItems(): Promise<MenuItem[]> {
    return Array.from(this.menuItems.values());
  }

  async getMenuItemsByCategory(category: string): Promise<MenuItem[]> {
    return Array.from(this.menuItems.values()).filter(item => item.category === category);
  }

  async createMenuItem(insertItem: InsertMenuItem): Promise<MenuItem> {
    const id = randomUUID();
    const menuItem: MenuItem = { ...insertItem, id };
    this.menuItems.set(id, menuItem);
    return menuItem;
  }

  async getWeeklySpecials(): Promise<WeeklySpecial[]> {
    return Array.from(this.weeklySpecials.values());
  }

  async getActiveWeeklySpecials(): Promise<WeeklySpecial[]> {
    return Array.from(this.weeklySpecials.values()).filter(special => special.active);
  }

  async createWeeklySpecial(insertSpecial: InsertWeeklySpecial): Promise<WeeklySpecial> {
    const id = randomUUID();
    const weeklySpecial: WeeklySpecial = { ...insertSpecial, id };
    this.weeklySpecials.set(id, weeklySpecial);
    return weeklySpecial;
  }
}

export const storage = new MemStorage();
